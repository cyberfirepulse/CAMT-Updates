'use strict';
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let lang=localStorage.getItem('camt_poc_language')||'nl',words={},state=null,tab='dashboard',matrixMode='accepted',detailId=null,reasonJob=null,teamAvailable=false,teamCases=[],captureDraft={},draftMeta={};
const tabs=['dashboard','capture','queue','matrix','relations','ops','team'];
const phoneQuery=matchMedia('(max-width:700px)');
$('#filters').open=!phoneQuery.matches;
phoneQuery.addEventListener('change',e=>$('#filters').open=!e.matches);
const t=k=>words[k]??k;
const label=(key,html,wide=false)=>`<label class="${wide?'wide':''}"><span>${esc(t(key))}</span>${html}</label>`;
const options=(values,selected)=>values.map(v=>`<option value="${esc(v)}" ${v===selected?'selected':''}>${esc(t(v))}</option>`).join('');
const badge=(key,cls='')=>`<span class="tag ${esc(cls)}">${esc(t(key))}</span>`;
const action=(act,key,id='',cls='')=>`<button type="button" data-action="${act}" data-id="${esc(id)}" class="${cls}">${esc(t(key))}</button>`;
const item=id=>state?.items.find(r=>r.id===id);
const analyst=()=>$('#analyst').value.trim();
function notify(message,error=false){const n=$('#toast');n.textContent=message;n.className=error?'error':'';n.style.display='block';clearTimeout(notify.timer);notify.timer=setTimeout(()=>n.style.display='none',6500);}
async function api(path,body){
 const result=await fetch(path,{method:body===undefined?'GET':'POST',headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),credentials:'same-origin'});
 const value=await result.json();
 if(!result.ok){const err=new Error(t(value.error||'operation_failed'));err.code=result.status;throw err;}
 return value;
}
async function attempt(job){try{return await job();}catch(e){notify(e.message,true);if(e.code===401)showLogin();}}
function translated(){document.documentElement.lang=lang;document.querySelectorAll('[data-i18n]').forEach(n=>n.textContent=t(n.dataset.i18n));$('#language').textContent=lang==='nl'?'English':'Nederlands';}
async function setLanguage(){const r=await fetch('/locales/'+lang+'.json');words=await r.json();translated();if(state)render();}
function showLogin(){$('#login').hidden=false;$('#app').hidden=true;$('#logout').hidden=true;}
async function showApp(){$('#login').hidden=true;$('#app').hidden=false;$('#logout').hidden=false;await refresh();}
async function refresh(){state=await api('/api/state');render();if(detailId&&$('#detail').open)showDetail(detailId);}
function filtered(){
 const needle=$('#search').value.toLowerCase(),sev=$('#severity').value,origin=$('#origin').value;
 return state.items.filter(r=>(sev==='all'||r.severity===sev)&&(origin==='all'||r.origin===origin)&&[r.title,r.description,r.source,r.asset].join(' ').toLowerCase().includes(needle));
}
function card(r){return `<article class="card sev-${esc(r.severity)}"><h3>${esc(r.title)}</h3><div class="tags">${badge(r.kind)}${badge(r.severity,'sev-'+r.severity)}${badge(r.status)}${badge(r.research_status||'open')}${r.demo?badge('demo','demo'):''}</div><p class="muted">${esc(r.asset||'—')} · ${esc(r.observed_at)} · ${esc(r.source)}</p><p class="preserve">${esc(r.description.slice(0,260))}</p><div class="tags">${r.mappings.map(m=>badge(m.technique_id+' · '+t(m.state),m.state)).join('')}</div>${r.supersedes?`<p class="muted">${esc(t('source_updated'))}</p>`:''}<div class="actions">${action('detail','detail',r.id)}</div></article>`;}
function title(key,hint){return `<h1>${esc(t(key))}</h1><p class="intro">${esc(t(hint))}</p>`;}
function render(){
 $('#nav').innerHTML=tabs.map(k=>`<button data-tab="${k}" class="${tab===k?'active':''}">${esc(t(k))}</button>`).join('');
 const views={dashboard:dashboard,capture:capture,queue:reviewQueue,matrix:matrix,relations:relations,ops:ops,team:team};
 $('#main').innerHTML=views[tab]();
 if(tab==='capture'){
  const f=$('#captureform');for(const [k,v] of Object.entries(captureDraft))if(f.elements[k])f.elements[k].value=v;
  f.addEventListener('input',()=>captureDraft=Object.fromEntries(new FormData(f)));
  f.addEventListener('submit',e=>{e.preventDefault();attempt(async()=>{if(!analyst())throw new Error(t('analyst_required'));const data=Object.fromEntries(new FormData(f));data.analyst=analyst();Object.assign(data,draftMeta);if(!data.observed_at)data.observed_at=new Date().toISOString();await api('/api/items',data);captureDraft={};draftMeta={};notify(t('saved'));tab='queue';await refresh();});});
 }
 if(tab==='queue')$('#researchfilter').onchange=e=>{researchFilter=e.target.value;render();};
 if(tab==='ops')$('#importfile').addEventListener('change',importFile);
 if(tab==='matrix')$('#matrixmode').addEventListener('change',e=>{matrixMode=e.target.value;render();});
 if(tab==='relations')$('#linkform').addEventListener('submit',e=>{e.preventDefault();const form=e.target;askReason('add_link',note=>change('/api/links',{...Object.fromEntries(new FormData(form)),analyst:analyst(),note}));});
 if(tab==='team'){
  $('#teamcases')?.addEventListener('change',e=>sessionStorage.setItem('camt_poc_case',e.target.value));
 }
}
function dashboard(){const rows=filtered();return title('dashboard','intro')+`<div class="flow">${['flow1','flow2','flow3','flow4'].map(k=>`<span>${esc(t(k))}</span>`).join(' → ')}</div><div class="metrics">${[
 [rows.length,'records'],[rows.filter(r=>r.status==='pending').length,'pending'],[rows.filter(r=>r.status!=='dismissed').reduce((n,r)=>n+r.mappings.filter(m=>m.state==='accepted').length,0),'accepted_count'],[rows.filter(r=>r.kind==='finding').length,'findings']
 ].map(([n,k])=>`<div class="metric"><b>${n}</b><small>${esc(t(k))}</small></div>`).join('')}</div><div class="grid"><section><h2>${esc(t('recent'))}</h2>${rows.length?rows.slice(0,5).map(card).join(''):`<p class="empty">${esc(t('empty'))}</p>`}</section><section class="panel"><h2>${esc(t('audit'))}</h2>${auditTable(state.audit.slice(0,12))}<p class="muted">${esc(t('offline_scope'))}</p></section></div>`;}
function capture(){return title('capture','capture_hint')+draftList()+`<form id="captureform" class="panel"><div class="formgrid">${
 label('kind',`<select name="kind">${options(['observation','alert','question'],'observation')}</select>`)+
 label('time','<input name="observed_at" type="text" placeholder="2026-11-04T10:00:00+01:00">')+
 label('title','<input name="title" maxlength="300" required>',true)+
 label('description','<textarea name="description" rows="5" maxlength="20000"></textarea>',true)+
 label('source','<input name="source" maxlength="600">')+label('asset','<input name="asset" maxlength="300">')+
 label('severity',`<select name="severity">${options(['info','low','medium','high','critical'],'info')}</select>`)+
 label('certainty',`<select name="certainty">${options(['observed','reported','inferred'],'observed')}</select>`)+
 label('confidence',`<select name="confidence">${options(['unknown','low','medium','high'],'unknown')}</select>`)+
 label('assessment','<textarea name="assessment" rows="3" maxlength="20000"></textarea>')+
 label('follow_up','<textarea name="follow_up" rows="3" maxlength="20000"></textarea>',true)
 }</div><button class="primary" type="submit">${esc(t('save'))}</button>${action('save_draft','save_draft')}${action('new_draft','new_draft')}</form>`;}
let researchFilter='all';
function reviewQueue(){const rows=filtered().filter(r=>researchFilter==='all'||(r.research_status||'open')===researchFilter);return title('queue','mapping_hint')+`<label>${esc(t('research_status'))}<select id="researchfilter">${options(['all','open','investigating','waiting','resolved'],researchFilter)}</select></label><div class="grid">${rows.length?rows.map(card).join(''):`<p class="empty">${esc(t('empty'))}</p>`}</div>`;}
function showDetail(id){const r=item(id);if(!r)return;detailId=id;
 $('#detailbody').innerHTML=`<h1>${esc(r.title)}</h1><div class="tags">${badge(r.kind)}${badge(r.severity,'sev-'+r.severity)}${badge(r.status)}${badge(r.research_status||'open')}${r.demo?badge('demo','demo'):''}</div><p class="muted">${esc(r.id)} · ${esc(t('revision'))} ${r.revision}</p><div class="grid"><div><h3>${esc(t('description'))}</h3><p class="preserve">${esc(r.description)}</p><h3>${esc(t('source'))}</h3><p class="preserve">${esc(r.source)}</p><p>${esc(t('asset'))}: ${esc(r.asset||'—')}</p><p>${esc(t('time'))}: ${esc(r.observed_at)}</p></div><div><h3>${esc(t('certainty'))}</h3><p>${esc(t(r.certainty))}</p><h3>${esc(t('confidence'))}</h3><p>${esc(t(r.confidence))}</p><h3>${esc(t('assessment'))}</h3><p class="preserve">${esc(r.assessment||'—')}</p><h3>${esc(t('follow_up'))}</h3><p class="preserve">${esc(r.follow_up||'—')}</p></div></div>
 ${r.derived_from?`<p class="muted">${esc(t('derived_from'))}: ${action('detail','detail',r.derived_from)}</p>`:''}
 <div class="actions">${action('edit_record','edit_record',r.id)}${action('history','history',r.id)}</div><div class="divider"></div><h2>${esc(t('mapping'))}</h2><p class="muted">${esc(t('mapping_hint'))}</p>${r.mappings.length?r.mappings.map(m=>`<section class="mapping"><a href="${esc(state.catalog.techniques.find(x=>x.id===m.technique_id).url)}" target="_blank" rel="noopener noreferrer">${esc(m.technique_id)} · ${esc(state.catalog.techniques.find(x=>x.id===m.technique_id).name)}</a><div class="tags">${badge(m.state,m.state)}${badge(m.origin)}</div><p class="muted">${esc(t('rule_hit'))}: ${esc(m.reason)}</p>${m.note?`<p class="preserve">${esc(m.analyst)} · ${esc(m.note)}</p>`:''}<div class="actions"><button class="accept" data-action="accept" data-id="${esc(r.id)}" data-tech="${esc(m.technique_id)}">${esc(t('accept'))}</button><button class="reject" data-action="reject" data-id="${esc(r.id)}" data-tech="${esc(m.technique_id)}">${esc(t('reject'))}</button></div></section>`).join(''):`<p class="empty">${esc(t('no_mapping'))}</p>`}
 <div class="tools"><select id="manualtech">${state.catalog.techniques.map(x=>`<option value="${esc(x.id)}">${esc(x.id+' · '+x.name)}</option>`).join('')}</select>${action('manual_mapping','add_mapping',r.id)}</div><div class="divider"></div><div class="actions">${action('review_record','review_record',r.id,'accept')}${action('dismiss','dismiss',r.id,'reject')}${r.kind!=='finding'?action('promote','promote',r.id,'primary'):''}</div><p class="muted">${esc(t('promote_hint'))}</p>`;
 if(!$('#detail').open)$('#detail').showModal();
}
function matrix(){const rows=filtered().filter(r=>r.status!=='dismissed');const tact=['Initial Access','Execution','Lateral Movement','Exfiltration','Impact'];const ranks={info:0,low:1,medium:2,high:3,critical:4};
 return title('matrix','matrix_hint')+`<div class="tools"><label>${esc(t('mapping_view'))}<select id="matrixmode"><option value="accepted" ${matrixMode==='accepted'?'selected':''}>${esc(t('accepted_only'))}</option><option value="proposed" ${matrixMode==='proposed'?'selected':''}>${esc(t('proposed_only'))}</option></select></label><span class="tag">${esc(t('coverage'))}</span></div><div class="matrix">${tact.map(tactic=>`<section class="matrixcol"><h3>${esc(t(tactic))}</h3>${state.catalog.techniques.filter(x=>x.tactic===tactic).map(tech=>{
 const hits=rows.filter(r=>r.mappings.some(m=>m.technique_id===tech.id&&m.state===matrixMode));const highest=hits.reduce((a,r)=>ranks[r.severity]>ranks[a]?r.severity:a,'info');
 return `<button class="technique ${hits.length?'sev-'+highest:''}" data-action="tech_detail" data-id="${tech.id}"><b>${tech.id}</b>${esc(tech.name)}<small>${hits.length?hits.length+' '+esc(t('records'))+' · '+esc(t(highest)):esc(t('no_hits'))}</small></button>`;
 }).join('')}</section>`).join('')}</div><p class="note">${esc(t('subset'))}</p>`;
}
function techniqueDetail(tid){const technique=state.catalog.techniques.find(x=>x.id===tid),rows=filtered().filter(r=>r.status!=='dismissed'&&r.mappings.some(m=>m.technique_id===tid&&m.state===matrixMode));detailId=null;
 $('#detailbody').innerHTML=`<h1>${esc(tid)} · ${esc(technique.name)}</h1><p class="muted">${esc(t(matrixMode==='accepted'?'accepted_only':'proposed_only'))}</p><p>${esc(t('matrix_hint'))}</p>${rows.length?rows.map(card).join(''):`<p class="empty">${esc(t('no_hits'))}</p>`}`;if(!$('#detail').open)$('#detail').showModal();}
function relations(){const visible=new Set(filtered().map(x=>x.id));const candidates=state.candidates.filter(l=>visible.has(l.left_id)&&visible.has(l.right_id));const links=state.links.filter(l=>visible.has(l.left_id)&&visible.has(l.right_id));const optionRecords=filtered().map(x=>`<option value="${esc(x.id)}">${esc(x.title)}</option>`).join('');
 return title('relations','relations_hint')+`<section class="panel"><h2>${esc(t('add_link'))}</h2><form id="linkform"><div class="formgrid">${label('left',`<select name="left_id" required>${optionRecords}</select>`)}${label('right',`<select name="right_id" required>${optionRecords}</select>`)}${label('relation_type',`<select name="relation">${options(['context','supports','contradicts'],'context')}</select>`)}</div><button type="submit" class="primary">${esc(t('add_link'))}</button></form></section><div class="grid"><section><h2>${esc(t('candidate_links'))}</h2>${candidates.length?candidates.slice(0,20).map(l=>`<article class="panel"><div class="relation"><div class="graphitem">${esc(item(l.left_id)?.title)}</div><div class="line">⋯ ${esc(t(l.reason))} ⋯</div><div class="graphitem">${esc(item(l.right_id)?.title)}</div></div><div class="actions">${action('detail','detail',l.left_id)}<button data-action="candidate" data-id="${esc(l.left_id)}" data-right="${esc(l.right_id)}">${esc(t('add_link'))} · ${esc(t('context'))}</button></div></article>`).join(''):`<p class="empty">${esc(t('none'))}</p>`}</section><section><h2>${esc(t('confirmed_links'))}</h2>${links.length?links.map(l=>`<article class="panel"><div class="relation"><div class="graphitem">${esc(item(l.left_id)?.title)}</div><div class="line">→ ${esc(t(l.relation))} →</div><div class="graphitem">${esc(item(l.right_id)?.title)}</div></div><p class="preserve">${esc(l.note)}</p><p class="muted">${esc(l.analyst)} · ${esc(l.created_at)}</p></article>`).join(''):`<p class="empty">${esc(t('none'))}</p>`}</section></div><section class="panel"><h2>${esc(t('timeline'))}</h2><p class="muted">${esc(t('not_causal'))}</p>${filtered().slice().sort((a,b)=>a.observed_at.localeCompare(b.observed_at)).map(r=>`<p>${esc(r.observed_at)} · ${esc(r.asset)} · ${action('detail',r.title,r.id)}</p>`).join('')}</section>`;
}
function ops(){const runs=state.runs;return title('ops','ops_hint')+`<div class="grid"><section class="panel"><h2>${esc(t('import'))}</h2><p class="muted">${esc(t('import_hint'))}</p><input id="importfile" type="file" accept=".json,.csv"><p class="muted">${esc(t('body_limit'))} · ${esc(t('import_limit'))}</p></section><section class="panel"><h2>${esc(t('source_status'))}</h2><div class="tablewrap"><table><tbody>${['Elasticsearch','Kibana webhook','NAG'].map(x=>`<tr><td>${x}</td><td>${esc(t('not_connected'))}</td></tr>`).join('')}<tr><td>JSON / CSV</td><td>${esc(runs.find(r=>r.source!=='Demo fixture')?.at||t('not_used'))}</td></tr><tr><td>${esc(t('demo'))}</td><td>${esc(runs.find(r=>r.source==='Demo fixture')?.at||t('not_used'))}</td></tr></tbody></table></div></section></div><section class="panel"><h2>${esc(t('import_runs'))}</h2><div class="tablewrap"><table><thead><tr>${['time','source','new','versions','duplicates','rejected_rows'].map(k=>`<th>${esc(t(k))}</th>`).join('')}</tr></thead><tbody>${runs.map(r=>`<tr><td>${esc(r.at)}</td><td>${esc(r.source)}</td><td>${r.payload.new}</td><td>${r.payload.versions}</td><td>${r.payload.duplicates}</td><td>${r.payload.rejected}${r.payload.errors.length?`<pre>${esc(JSON.stringify(r.payload.errors,null,2))}</pre>`:''}</td></tr>`).join('')}</tbody></table></div></section><section class="panel"><h2>${esc(t('audit'))}</h2>${auditTable(state.audit)}</section>`;}
function auditTable(rows){return rows.length?`<div class="tablewrap"><table><thead><tr>${['time','analyst','follow_up'].map(k=>`<th>${esc(t(k))}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.at)}</td><td>${esc(r.analyst)}</td><td>${esc(r.action)}<br><span class="muted">${esc(r.detail)}</span></td></tr>`).join('')}</tbody></table></div>`:`<p class="muted">${esc(t('none'))}</p>`;}
function team(){const selected=sessionStorage.getItem('camt_poc_case')||'',findings=state.items.filter(r=>r.kind==='finding'&&r.status==='reviewed');return title('team','team_hint')+(!teamAvailable?`<p class="note">${esc(t('team_unavailable'))}</p>`:`<section class="panel"><div class="actions">${action('load_cases','load_cases')}</div><div class="formgrid">${label('select_case',`<select id="teamcases"><option value="">—</option>${teamCases.map(c=>`<option value="${esc(c.case_id)}" ${c.case_id===selected?'selected':''}>${esc(c.title+' · '+c.case_id)}</option>`).join('')}</select>`)}${label('choose_finding',`<select id="teampublish"><option value="">—</option>${findings.map(r=>`<option value="${esc(r.id)}">${esc(r.title)}</option>`).join('')}</select>`)}</div><div class="actions">${action('pull','pull')}${action('publish','publish','','primary')}</div></section>`);}

function draftList(){return `<section class="panel"><h2>${esc(t('drafts'))}</h2><p>${esc(t('draft_hint'))}</p>${state.drafts.length?state.drafts.map(d=>`<p>${esc(d.title||t('untitled'))} · ${esc(d.updated_at)} ${action('resume_draft','resume_draft',d.draft_id)} ${action('delete_draft','delete_draft',d.draft_id)}</p>`).join(''):`<p>${esc(t('none'))}</p>`}</section>`;}
const editDialog=document.createElement('dialog');editDialog.id='editdialog';document.body.append(editDialog);
function editRecord(r){
 const fields=['title','description','source','asset','observed_at','severity','certainty','confidence','assessment','follow_up','research_status'];
 const enums={severity:['info','low','medium','high','critical'],certainty:['observed','reported','inferred'],confidence:['unknown','low','medium','high'],research_status:['open','investigating','waiting','resolved']};
 editDialog.innerHTML=`<h2>${esc(t('edit_record'))}</h2><p>${esc(t('edit_hint'))}</p><form id="editform"><div class="formgrid">${fields.map(k=>label(k=== 'observed_at'?'time':k,enums[k]?`<select name="${k}">${options(enums[k],r[k]||'open')}</select>`:`<textarea name="${k}" rows="${['description','assessment','follow_up'].includes(k)?3:1}" maxlength="${k==='title'||k==='asset'?300:k==='source'?600:20000}" ${k==='title'?'required':''}>${esc(r[k])}</textarea>`,['description','assessment','follow_up'].includes(k))).join('')}${label('change_reason','<textarea name="reason" required maxlength="4000"></textarea>',true)}</div><button type="submit" class="primary">${esc(t('save'))}</button><button type="button" id="canceledit">${esc(t('cancel'))}</button></form>`;
 $('#canceledit').onclick=()=>editDialog.close();
 $('#editform').onsubmit=e=>{e.preventDefault();const values=Object.fromEntries(new FormData(e.target));const reason=values.reason;delete values.reason;attempt(async()=>{await change('/api/edit',{id:r.id,base_revision:r.revision,values,reason,analyst:analyst()});editDialog.close();});};
 editDialog.showModal();
}
async function showHistory(id){const versions=await api('/api/history',{id});editDialog.innerHTML=`<h2>${esc(t('history'))}</h2><p>${esc(t('history_hint'))}</p>${versions.map(r=>`<details><summary>${esc(t('revision'))} ${r.revision} · ${esc(r.title)}</summary><div class="tags">${badge(r.status)}${badge(r.research_status||'open')}</div><p class="muted">${esc(r.updated_at||r.created_at)} · ${esc(r.updated_by||r.analyst)}</p><p class="preserve">${esc(r.change_reason||'')}</p>${['title','description','source','asset','observed_at','severity','certainty','confidence','assessment','follow_up'].map(k=>`<h3>${esc(t(k==='observed_at'?'time':k))}</h3><p class="preserve">${esc(['severity','certainty','confidence'].includes(k)?t(r[k]):r[k])}</p>`).join('')}<h3>${esc(t('mapping'))}</h3>${r.mappings.map(m=>`<p>${esc(m.technique_id)} · ${esc(t(m.state))} · ${esc(m.analyst)} · ${esc(m.note)}</p>`).join('')}</details>`).join('')}<button id="closehistory">${esc(t('close'))}</button>`;$('#closehistory').onclick=()=>editDialog.close();editDialog.showModal();}

async function change(path,data){await api(path,data);await refresh();notify(t('saved'));}
function askReason(key,job){if(!analyst()){notify(t('analyst_required'),true);return;}reasonJob=job;$('#reason_title').textContent=t(key);$('#reasonform').reset();$('#reason').showModal();}
$('#reasonform').addEventListener('submit',e=>{e.preventDefault();const note=e.target.elements.note.value.trim();if(!note)return;attempt(async()=>{const button=e.target.querySelector('button[type=submit]');button.disabled=true;try{await reasonJob(note);$('#reason').close();}finally{button.disabled=false;}});});
$('#cancelreason').onclick=()=>$('#reason').close();$('#closedetail').onclick=()=>{detailId=null;$('#detail').close();};
document.addEventListener('click',e=>{
 const b=e.target.closest('button[data-action]');if(!b)return;const id=b.dataset.id,r=item(id),a=b.dataset.action;
 if(a==='edit_record'){editRecord(r);return;}
 if(a==='history'){attempt(()=>showHistory(id));return;}
 if(a==='save_draft'){attempt(async()=>{captureDraft=Object.fromEntries(new FormData($('#captureform')));const saved=await api('/api/drafts/save',{...draftMeta,values:captureDraft});draftMeta={draft_id:saved.draft_id,draft_revision:saved.draft_revision};await refresh();notify(t('draft_saved'));});return;}
 if(a==='new_draft'){if(Object.keys(captureDraft).length&&!confirm(t('leave_draft')))return;captureDraft={};draftMeta={};render();return;}
 if(a==='resume_draft'){if(Object.keys(captureDraft).length&&!confirm(t('leave_draft')))return;const d=state.drafts.find(x=>x.draft_id===id);const {draft_id,draft_revision,updated_at,...values}=d;captureDraft=values;draftMeta={draft_id,draft_revision};tab='capture';render();return;}
 if(a==='delete_draft'){if(!confirm(t('delete_draft_confirm')))return;attempt(async()=>{const d=state.drafts.find(x=>x.draft_id===id);await api('/api/drafts/delete',{draft_id:id,draft_revision:d.draft_revision});if(draftMeta.draft_id===id){draftMeta={};captureDraft={};}await refresh();});return;}
 if(a==='detail'){showDetail(id);return;}if(a==='tech_detail'){techniqueDetail(id);return;}
 if(a==='accept'||a==='reject'||a==='manual_mapping'){
  const tid=a==='manual_mapping'?$('#manualtech').value:b.dataset.tech;
  askReason(a==='reject'?'reject':'accept',note=>change('/api/review',{id,base_revision:r.revision,technique_id:tid,state:a==='reject'?'rejected':'accepted',analyst:analyst(),note}));return;
 }
 if(a==='review_record'||a==='dismiss'){askReason(a,note=>change('/api/decision',{id,base_revision:r.revision,state:a==='dismiss'?'dismissed':'reviewed',analyst:analyst(),note}));return;}
 if(a==='promote'){askReason('promote',async note=>{await api('/api/promote',{id,base_revision:r.revision,analyst:analyst(),assessment:note});await refresh();notify(t('promote_hint'));});return;}
 if(a==='candidate'){askReason('add_link',note=>change('/api/links',{left_id:id,right_id:b.dataset.right,relation:'context',analyst:analyst(),note}));return;}
 if(a==='load_cases'){attempt(async()=>{teamCases=(await api('/api/team/cases')).cases;render();});return;}
 if(a==='pull'){attempt(async()=>{const cid=$('#teamcases').value;if(!cid)throw new Error(t('select_case'));const counts=await api('/api/team/pull',{case_id:cid});await refresh();showCounts(counts);});return;}
 if(a==='publish'){attempt(async()=>{const cid=$('#teamcases').value,id=$('#teampublish').value;if(!cid||!id)throw new Error(t('choose_finding'));if(!analyst())throw new Error(t('analyst_required'));if(!confirm(t('publish_confirm')))return;await api('/api/team/publish',{case_id:cid,id,base_revision:item(id).revision,analyst:analyst()});await refresh();notify(t('published'));});}
});
$('#nav').onclick=e=>{const b=e.target.closest('[data-tab]');if(b){tab=b.dataset.tab;render();}};
for(const id of ['search','severity','origin'])$('#'+id).addEventListener(id==='search'?'input':'change',()=>{if(state)render();});
$('#analyst').value=localStorage.getItem('camt_poc_analyst')||'';$('#analyst').oninput=e=>localStorage.setItem('camt_poc_analyst',e.target.value);
$('#seed').onclick=()=>attempt(async()=>{if(!confirm(t('seed_confirm')))return;showCounts(await api('/api/seed',{}));await refresh();});
$('#refresh').onclick=()=>attempt(refresh);
$('#export').onclick=()=>attempt(async()=>{if(!confirm(t('export_hint')))return;const data=await api('/api/export');const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download='CAMT-Intel-PoC-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);});
$('#language').onclick=()=>attempt(async()=>{lang=lang==='nl'?'en':'nl';localStorage.setItem('camt_poc_language',lang);await setLanguage();if(detailId&&$('#detail').open)showDetail(detailId);});
$('#loginform').onsubmit=e=>{e.preventDefault();attempt(async()=>{await api('/api/login',{code:e.target.elements.code.value});e.target.reset();await showApp();});};
$('#logout').onclick=()=>attempt(async()=>{await api('/api/logout',{});state=null;showLogin();});
function showCounts(c){notify(`${t('imported')}: ${c.new} ${t('new')}, ${c.versions} ${t('versions')}, ${c.duplicates} ${t('duplicates')}, ${c.rejected} ${t('rejected_rows')}`);}
function parseCSV(text){
 const rows=[];let row=[],cell='',quoted=false,afterQuote=false;
 for(let i=0;i<text.length;i++){const ch=text[i];if(ch==='"'){if(afterQuote)throw new Error(t('invalid_record'));if(quoted&&text[i+1]==='"'){cell+='"';i++;}else if(quoted){quoted=false;afterQuote=true;}else{if(cell.length)throw new Error(t('invalid_record'));quoted=true;}}else if(ch===','&&!quoted){row.push(cell);cell='';afterQuote=false;}else if((ch==='\n'||ch==='\r')&&!quoted){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell='';afterQuote=false;}else{if(afterQuote)throw new Error(t('invalid_record'));cell+=ch;}}
 if(quoted)throw new Error(t('invalid_record'));row.push(cell);if(row.some(x=>x.trim()))rows.push(row);if(rows.length<2)throw new Error(t('invalid_record'));
 const headers=rows.shift().map(x=>x.trim().replace(/^\uFEFF/,''));if(new Set(headers).size!==headers.length)throw new Error(t('invalid_record'));
 return rows.map(values=>{if(values.length!==headers.length)throw new Error(t('invalid_record'));return Object.fromEntries(headers.map((h,i)=>[h,values[i]]));});
}
async function importFile(e){const file=e.target.files[0];if(!file)return;await attempt(async()=>{if(file.size>2*1024*1024)throw new Error(t('body_limit'));const text=await file.text();let records;if(file.name.toLowerCase().endsWith('.csv'))records=parseCSV(text);else{const j=JSON.parse(text.replace(/^\uFEFF/,''));records=Array.isArray(j)?j:j.records;}const counts=await api('/api/import',{records,source_name:file.name});await refresh();showCounts(counts);});}
attempt(async()=>{await setLanguage();const session=await api('/api/session');teamAvailable=session.team_available;if(session.authenticated)await showApp();else showLogin();});
