# Nieuw in versie 0.2.0 — dagelijkse onderzoeksworkflow

- Record bekijken → Record bewerken: titel, beschrijving, bron, asset, tijdstip, ernst, informatiebasis, vertrouwen, beoordeling en vervolgactie corrigeren. Reden en analist zijn verplicht. Recordtype en bron-event-ID blijven behouden.
- Wijzigingshistorie toont oude en huidige versies, inclusief beoordelingen en techniekkoppelingen. Historie wordt vanaf deze versie opgebouwd; oudere 0.1.0-wijzigingen kunnen niet achteraf worden gereconstrueerd.
- Inhoudelijke correcties zetten de beoordeling terug naar te beoordelen en berekenen techniekvoorstellen opnieuw. Eerdere beslissingen blijven in de historie. Alleen onderzoeksstatus of vervolgactie aanpassen behoudt bestaande beoordelingen.
- Onderzoeksstatus: Open, In onderzoek, Wacht op informatie, Afgerond. Deze staat los van inhoudelijke beoordeling en is filterbaar in de beoordelingswachtrij.
- Concept bewaren slaat onvolledige invoer expliciet op in SQLite (maximaal 100 concepten). Geen automatische opslag: bewaar vóór sluiten of herladen. Concepten zijn gedeeld binnen deze PoC en staan buiten de beoordelingswachtrij, matrix en Team-publicatie. Verder bewerken hervat een concept; opslaan als record verwijdert dat concept in dezelfde transactie. Revisieconflicten voorkomen stil overschrijven. Nieuw leeg formulier wist alleen de huidige invoer, niet een eerder bewaard concept.

## Bijwerken en gegevens behouden

Stop de draaiende PoC eerst. Maak voor de update een kopie van het bestaande `poc.sqlite` terwijl de PoC gestopt is. Importeer vervolgens het 0.2.0-modulepakket met dezelfde package-ID via CAMT. De opslagmap blijft `observation-intel-poc` onder de bestaande CAMT-gebruikersgegevensmap. De database wordt bij starten alleen uitgebreid met tabellen voor historie en concepten; bestaande records blijven bewaard.

Los pakket: pak volledig uit. Wil je bestaande losse gegevens meenemen, kopieer dan de eerder gestopte database naar `data/poc.sqlite` naast de nieuwe startbestanden. Een lege installatie start leeg. Gebruik Start_PoC.cmd, of Start_PoC_LAN.cmd voor de bestaande LAN-testopzet.

De JSON-export blijft een onderzoeksmomentopname, geen herstelpakket: deze bevat nu ook concepten, maar niet de volledige revisiehistorie. Voor een volledige back-up met historie: stop de PoC en kopieer `poc.sqlite`.

Validatie: automatische opslag-, migratie-, conflict-, HTTP-, import- en Team-brugtests geslaagd; browsercontrole met fictieve gegevens voor concept → onderzoeksvraag → status/vervolgactie → historie, NL/EN. Geen installatie in jouw actieve CAMT en geen fysieke telefoontest uitgevoerd. De Android-APK blijft versie 0.1.0.

## Bestaande PoC-informatie (0.1.0, behalve waar hierboven uitgebreid)

# CAMT Observation Intel — Proof of Concept 0.1.0

Een werkende proef van **observatie → technische signalen → beoordeling → verbanden → bevinding**. De webinterface werkt op pc en telefoon. Dit pakket vervangt de bestaande Android-APK of CAMT-core niet.

## Starten als CAMT-module — aanbevolen

1. Importeer `CAMT_Observation_Intel_PoC_v0_1_0.camtmodule` via CAMT’s bestaande modulemanager. Bevestig de installatie als vertrouwde codemodule.
2. Open **Observation Intel PoC** via de modulemanager of module-navigatie.
3. Voor alleen de pc: laat de LAN-optie uit. Voor testen op de telefoon: vink **Ook bereikbaar op vertrouwd LAN** aan vóór starten.
4. Kies **PoC starten**. De browser opent op `http://127.0.0.1:8787`.
5. Voer de getoonde toegangscode in. Deze verandert na iedere herstart van de PoC-server.
6. Op de telefoon open je `http://<LAN-IP-van-de-pc>:8787` en gebruik je dezelfde code. Beide toestellen moeten elkaar kunnen bereiken. Houd de firewall ingeschakeld; beperk eventuele toestemming tot het privénetwerk.

Het startvenster blijft open zolang je de PoC gebruikt. **PoC stoppen** sluit de webserver. Bij een bezette poort wordt geen bestaand proces afgesloten.

### Afzonderlijk starten

Pak `CAMT_Observation_Intel_PoC_0_1_0.zip` volledig uit. Dubbelklik **Start_PoC.cmd** voor alleen de pc of **Start_PoC_LAN.cmd** voor een vertrouwd lokaal netwerk. Vereist Python 3.12 of hoger, zonder aanvullende pakketten. De toegangscode staat in het consolevenster. Sluit af met Ctrl+C.

Los starten heeft geen koppeling met je bestaande CAMT-teamconfiguratie. Gebruik daarvoor de CAMT-modulevariant.

## Proef in ongeveer vijf minuten

1. Klik **Demogegevens laden**. Dit voegt acht expliciet fictieve records toe. Niets wordt vooraf als geaccepteerd aangemerkt. Nogmaals laden slaat exacte dubbelingen over.
2. Vul bij **Naam analist** een herkenbaar testlabel in.
3. Open **Observatie vastleggen**. Noteer bijvoorbeeld een gezien PowerShell-venster, de bron, een assetnaam en wat nog moet worden onderzocht. Ernst, informatiebasis en vertrouwen zijn afzonderlijke velden.
4. Open het record in de **Beoordelingswachtrij**. Je ziet een **voorgestelde** T1059-koppeling en de tekst waarop die berust.
5. Accepteer of verwerp de koppeling met een reden. Dit is een beoordeling van de koppeling; het bewijst geen kwaadaardig gebruik. Een PowerShell-vermelding alleen is geen bewijs van een aanval.
6. Open **ATT&CK**. Wissel tussen **Voorstellen** en **Geaccepteerde koppelingen**. Klik een cel om de onderliggende bronrecords te zien.
7. Open **Onderzoeksbeeld**. Records met dezelfde asset en maximaal twee uur verschil krijgen een contextvoorstel. Bevestig desgewenst een relatie met onderbouwing: ondersteunt, spreekt tegen of context. Tijdsvolgorde en gedeelde assets worden niet automatisch tot een aanvalspad verheven.
8. Maak vanuit een bronrecord een **afzonderlijke bevinding**, met beoordeling. Het oorspronkelijke record blijft bewaard.

Op een telefoon zijn de filters en hulpmiddelen inklapbaar. Nederlands en Engels zijn wisselbaar; de UI-teksten staan in afzonderlijke JSON-bestanden. Bronteksten van onderzoeksrecords worden niet automatisch vertaald.

## Technische meldingen importeren

**Bronnen & imports** accepteert een genormaliseerde JSON-array, `{"records": [...]}` of CSV met deze veldnamen:

`kind,title,description,source,source_event_id,asset,observed_at,severity,certainty,confidence,techniques`

- `kind`: observation, alert, finding of question.
- `severity`: info, low, medium, high of critical.
- `certainty`: observed, reported of inferred.
- `confidence`: unknown, low, medium of high.
- `observed_at`: ISO-tijd mét tijdzone, bijvoorbeeld `2026-11-04T10:00:00+01:00`.
- `techniques`: JSON-lijst of een CSV-veld met door puntkomma’s gescheiden PoC-techniek-ID’s.
- Een titel en geldige observatietijd zijn bij import verplicht. Andere ontbrekende velden krijgen de gedocumenteerde neutrale standaardwaarden.

Gebruik de meegeleverde `examples/import_example.json` en `.csv` om te testen. Deze bevatten duidelijk benoemde fictieve brongegevens. Bronmappingen worden voorstellen, nooit automatisch geaccepteerde conclusies.

Maximaal 500 records per import, 2 MB per HTTP-verzoek en 1000 records in een PoC-database. De resultaatlijst toont nieuwe records, bronupdates, exacte dubbelingen en afgewezen regels. Een bronupdate met hetzelfde bron-event-ID wordt als afzonderlijke versie bewaard, zodat een eerdere beoordeling niet ongemerkt wordt vervangen. Rijen zonder tijdzone of met technieken buiten de subset worden afgewezen.

**Geen rechtstreekse NAG-, Elasticsearch- of Kibana-connector:** die staan expliciet als niet aangesloten vermeld. Ook een webhookontvanger is nog niet gebouwd. Dit is de proef voor de gegevens- en beoordelingsstroom, niet een volledige SIEM-ingestservice.

## Optionele uitwisseling met CAMT Team

Dit werkt alleen wanneer de PoC vanuit de CAMT-module is gestart terwijl CAMT al in teammodus staat met serveradres en token. De PoC gebruikt dan de bestaande TeamService en licentiecontroles. Er komt geen token in de browser, export of een tweede configuratiebestand.

- **Teamdossiers ophalen** leest de beschikbare dossiers.
- **Dossierobservaties / bevindingen importeren** neemt ondersteunde objecten over naar de aparte PoC-opslag. Ze krijgen de status te beoordelen; bestaande serverbeoordelingen worden niet automatisch vertrouwd.
- **Beoordeelde bevinding publiceren** schrijft uitsluitend de gekozen bevinding naar het gekozen teamdossier, na een expliciete bevestiging. Dit is de enige functie die onderzoeksinhoud naar de bestaande teamserver schrijft.
- Het record krijgt een stabiel serverobject-ID. Een volgende publicatie gebruikt het eerder bevestigde revisienummer. Bij conflicten wordt niet geforceerd overschreven.
- Publiceer eerst in een testdossier. De team-auditidentiteit komt uit de bestaande CAMT-configuratie. De browsernaam is een aanvullend auditlabel, geen persoonlijke authenticatie.

Bij een gewijzigde CAMT-serverconfiguratie moet de PoC worden herstart. Bij een netwerkstoring na publicatie kan de server de wijziging al hebben opgeslagen; controleer bij een vervolgend revisieconflict de serverinhoud. Er wordt niet automatisch opnieuw geschreven.

## Wat deze PoC wel en nog niet aantoont

Wel: mobiel/desktop invoer, afzonderlijke bron/interpretatie, handmatige beoordeling, verklaarbare trefwoordvoorstellen, een doorklikbare matrix-subset, contextrelaties, bronupdates/dubbelingen, lokale opslag, audit, genormaliseerde imports en expliciete teamuitwisseling.

Nog niet: native uitbreiding van de Android-app, foto's/bijlagen uploaden, spraak naar observatie, automatische CTI-verrijking, volledige ATT&CK-catalogus of subtechnieken, detectiedekkingsberekening, actorattributie, bewezen aanvalspaden, alertpolling/webhooks, persoonlijke aanmelding/rollen of een productieklare externe dienst.

De geselecteerde catalogus bevat zes technieken, gecontroleerd tegen de officiële MITRE-pagina’s op 4 november 2026. Iedere techniek verwijst naar zijn officiële bron. De matrix is geen volledige versie van ATT&CK. Ook geen records in een cel zegt niets over afwezigheid van een aanval of voldoende detectie.

Records en beslissingen blijven in deze proef bewaard. Correcties kunnen als nieuw record of door gemotiveerd terzijde leggen worden vastgelegd. Een volledige recordeditor en herstel-/verwijderworkflow zijn nog niet aanwezig.

## Opslag, toegang en export

- Als module: een aparte map `observation-intel-poc` onder CAMT’s bestaande gebruikersgegevensmap. Bij los starten: `data/poc.sqlite` naast de startbestanden.
- De SQLite-opslag is lokaal en niet aanvullend versleuteld. Gebruik voor deze proef testgegevens.
- De tijdelijke toegangscode geeft toegang tot deze PoC, inclusief eventueel beschikbare teamacties. Deel hem alleen met je testdeelnemers. Sessies verlopen na acht uur en worden bij herstart ongeldig. Persoonlijke accounts en rollen ontbreken nog.
- Standaard alleen loopback. LAN-bereikbaarheid is een expliciete keuze. Deze PoC gebruikt HTTP; daarmee zijn gegevens en toegangscode op het LAN niet versleuteld. Niet bedoeld voor publicatie op internet.
- Geen automatische camera-, locatie-, contact- of telemetrieverzameling. Geen cloudregistratie vereist.
- Analistnaam en taal worden als browservoorkeur bewaard. Toegangssessies gebruiken een HttpOnly/SameSite-cookie; servercredentials worden niet naar de browser gestuurd.
- **Onderzoeksmomentopname exporteren** bevat de opgeslagen records, relaties, importresultaten en de laatste 200 auditregels. Het is geen databaseherstelpakket. Voor een complete back-up stop je de PoC en kopieer je `poc.sqlite`.

## Controle

Functionele tests zijn uitgevoerd met afzonderlijke databases en een aparte instantie van de bestaande CAMT-teamserverbroncode. Ook in de browser zijn opslaan, techniekbeoordeling, doorklikken, een contextrelatie en de NL/EN-weergave gecontroleerd. De mobiele layout is op een viewport van 390 × 844 gecontroleerd; deze PoC is nog niet op jouw fysieke telefoon beproefd.

Ondersteuning: cyberfirepulse@gmail.com
