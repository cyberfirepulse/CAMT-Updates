from __future__ import annotations
import argparse,hashlib,hmac,json,mimetypes,secrets,threading,time,webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import importlib.util,sys

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('camt_intel_poc_backend',HERE/'backend.py')
core=importlib.util.module_from_spec(spec);sys.modules[spec.name]=core;spec.loader.exec_module(core)

class Server(ThreadingHTTPServer):
 daemon_threads=True
 def __init__(self,host='127.0.0.1',port=8787,data_dir=None,team_service=None):
  self.store=core.Store(Path(data_dir or HERE/'data')/'poc.sqlite')
  self.code=secrets.token_urlsafe(12);self.sessions={};self.failures={};self.auth_lock=threading.Lock()
  self.bridge=core.TeamBridge(team_service,self.store) if team_service is not None else None
  super().__init__((host,port),Handler)
 @property
 def url(self):return 'http://127.0.0.1:'+str(self.server_port)

class Handler(BaseHTTPRequestHandler):
 server_version='CAMT-Intel-PoC/0.2'
 def log_message(self,*a):pass
 def response(self,status,value,headers=None):
  raw=json.dumps(value,ensure_ascii=False).encode('utf-8')
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)))
  self.security()
  for k,v in (headers or {}).items():self.send_header(k,v)
  self.end_headers();self.wfile.write(raw)
 def security(self):
  self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
  self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY')
  self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
 def authenticated(self):
  cookie=self.headers.get('Cookie','');token=''
  for value in cookie.split(';'):
   if value.strip().startswith('camt_poc='):token=value.strip()[9:]
  with self.server.auth_lock:
   expiry=self.server.sessions.get(token,0)
   if expiry>time.time():return True
  return False
 def origin_ok(self):
  origin=self.headers.get('Origin','')
  if not origin:return False
  parsed=urlsplit(origin)
  return parsed.scheme=='http' and parsed.netloc==self.headers.get('Host','')
 def body(self):
  if self.headers.get_content_type()!='application/json':raise core.Problem(415,'json_required')
  try:length=int(self.headers.get('Content-Length','0'))
  except ValueError:raise core.Problem(400,'invalid_length')
  if length<1 or length>core.MAX_BODY:raise core.Problem(413,'body_limit')
  try:value=json.loads(self.rfile.read(length))
  except (ValueError,UnicodeError):raise core.Problem(400,'invalid_json')
  if not isinstance(value,dict):raise core.Problem(400,'invalid_json')
  return value
 def do_GET(self):
  path=urlsplit(self.path).path
  if path in ('/','/index.html','/app.js','/style.css','/locales/en.json','/locales/nl.json'):
   name='index.html' if path=='/' else path[1:]
   file=HERE/'web'/name
   raw=file.read_bytes();self.send_response(200);self.send_header('Content-Type',mimetypes.guess_type(name)[0] or 'text/plain');self.send_header('Content-Length',str(len(raw)));self.security();self.end_headers();self.wfile.write(raw);return
  if path=='/api/session':self.response(200,{'authenticated':self.authenticated(),'team_available':self.server.bridge is not None});return
  if not self.authenticated():self.response(401,{'error':'unauthorized'});return
  try:
   if path=='/api/state':self.response(200,self.server.store.state())
   elif path=='/api/export':self.response(200,{'schema':'camt.observation_intel.poc.export','version':1,'exported_at':core.now(),'data':self.server.store.state()})
   elif path=='/api/team/cases':
    if not self.server.bridge:raise core.Problem(400,'team_unavailable')
    self.response(200,{'cases':self.server.bridge.cases()})
   else:self.response(404,{'error':'not_found'})
  except core.Problem as e:self.response(e.code,{'error':e.message})
  except Exception:self.response(502,{'error':'team_request_failed'})
 def do_POST(self):
  try:
   if not self.origin_ok():raise core.Problem(403,'origin_rejected')
   path=urlsplit(self.path).path;v=self.body()
   if path=='/api/login':
    peer=self.client_address[0];at=time.time()
    with self.server.auth_lock:
     failures=[x for x in self.server.failures.get(peer,[]) if at-x<60]
     if len(failures)>=8:raise core.Problem(429,'login_throttled')
     if not hmac.compare_digest(str(v.get('code','')),self.server.code):
      self.server.failures[peer]=failures+[at];raise core.Problem(401,'wrong_code')
     self.server.sessions={t:e for t,e in self.server.sessions.items() if e>at}
     if len(self.server.sessions)>=100:raise core.Problem(429,'session_limit')
     token=secrets.token_urlsafe(32);self.server.sessions[token]=at+8*3600;self.server.failures.pop(peer,None)
    self.response(200,{'ok':True},{'Set-Cookie':'camt_poc='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'});return
   if not self.authenticated():raise core.Problem(401,'unauthorized')
   if path=='/api/logout':
    # Expire the current cookie; server-side session tokens are short-lived and non-reusable by this browser.
    cookie=self.headers.get('Cookie','')
    with self.server.auth_lock:
     for part in cookie.split(';'):
      if part.strip().startswith('camt_poc='):self.server.sessions.pop(part.strip()[9:],None)
    self.response(200,{'ok':True},{'Set-Cookie':'camt_poc=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});return
   store=self.server.store
   if path=='/api/items':result=store.add(v)
   elif path=='/api/edit':result=store.edit(v)
   elif path=='/api/history':result=store.history(core.clean(v.get('id',''),100))
   elif path=='/api/drafts/save':result=store.save_draft(v)
   elif path=='/api/drafts/delete':result=store.delete_draft(v)
   elif path=='/api/review':result=store.review(v)
   elif path=='/api/decision':result=store.decision(v)
   elif path=='/api/promote':result=store.promote(v)
   elif path=='/api/links':result=store.link(v)
   elif path=='/api/seed':result=store.seed()
   elif path=='/api/import':result=store.import_records(v.get('records'),source_name=core.clean(v.get('source_name','JSON / CSV'),200))
   elif path=='/api/team/pull':
    if not self.server.bridge:raise core.Problem(400,'team_unavailable')
    result=self.server.bridge.pull(core.clean(v.get('case_id',''),100))
   elif path=='/api/team/publish':
    if not self.server.bridge:raise core.Problem(400,'team_unavailable')
    result=self.server.bridge.publish(core.clean(v.get('id',''),100),core.clean(v.get('case_id',''),100),v.get('analyst',''),v.get('base_revision'))
   else:raise core.Problem(404,'not_found')
   self.response(200,result)
  except core.Problem as e:self.response(e.code,{'error':e.message})
  except Exception as e:
   if '409' in str(e) and 'revision_conflict' in str(e):self.response(409,{'error':'revision_conflict'})
   else:self.response(502,{'error':'operation_failed'})

def main():
 p=argparse.ArgumentParser();p.add_argument('--host',default='127.0.0.1',choices=['127.0.0.1','0.0.0.0']);p.add_argument('--port',type=int,default=8787);p.add_argument('--data-dir',type=Path,default=HERE/'data');p.add_argument('--no-browser',action='store_true');args=p.parse_args()
 server=Server(args.host,args.port,args.data_dir)
 print('CAMT Observation Intel PoC:',server.url,flush=True)
 print('Access code / Toegangscode:',server.code,flush=True)
 if args.host=='0.0.0.0':print('LAN enabled: use this PC IPv4 address with port '+str(server.server_port)+'. HTTP is unencrypted; use test data on a trusted network.',flush=True)
 if not args.no_browser:webbrowser.open(server.url)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:server.server_close()

if __name__=='__main__':main()
