# Version 0.2.0 — research workflow

Records can now be edited with a required analyst label, change reason and revision check. Historical snapshots retain superseded record versions and mapping decisions from this version onward. Older changes cannot be reconstructed. Content corrections reset review to pending and regenerate mapping proposals. Changing only research status or follow-up preserves review decisions.

Research status is separate from evidence review: Open, Investigating, Awaiting information, Resolved. Filter it in the review queue. Record type and source event ID remain fixed.

Use Save draft explicitly before closing or reloading. Up to 100 incomplete drafts persist in SQLite across restarts and are shared by this PoC's users. Drafts do not enter the matrix, review queue or Team publication. Resume a draft, then save as a record: conversion and draft removal are atomic. Revision conflicts prevent overwrites. New empty form clears current input without deleting a saved draft.

Stop the old PoC and back up its poc.sqlite before updating. Import the 0.2.0 module with the same package ID; the existing observation-intel-poc data folder is retained. Startup adds history and drafts tables without replacing existing records. For the standalone ZIP, copy a stopped existing database to data/poc.sqlite beside the extracted start files if needed.

JSON snapshot exports include drafts, but not full revision history, and remain unsuitable for restore. For full backup stop the PoC and copy poc.sqlite.

Automated persistence, migration, conflict, HTTP, import and Team bridge checks passed. Browser workflow checked using synthetic data in NL/EN. No installation in the active CAMT instance or physical phone test performed. Android APK remains 0.1.0.

## Original 0.1.0 reference (except features extended above)

# CAMT Observation Intel — Proof of Concept 0.1.0

Working proof of the workflow: observation → technical signals → analyst review → relationships → finding. Responsive web UI for desktop and phone; separate from the existing native Android APK and CAMT core.

## Launch

Recommended: import the `.camtmodule` in CAMT's module manager, approve as trusted code and open Observation Intel PoC. Start the PoC, then enter its temporary access code in the browser. Enable the trusted-LAN option before starting if a phone should connect using the PC's LAN IPv4 address and port 8787.

Alternatively extract the standalone ZIP and run `Start_PoC.cmd` (loopback) or `Start_PoC_LAN.cmd` (trusted LAN). Requires Python 3.12+; no extra packages. Standalone mode has no CAMT Team bridge. Stop its console with Ctrl+C.

## Try it

Load the explicitly fictitious demo data, enter an analyst label, capture an observation, review a proposed technique with a reason and open the ATT&CK cell to inspect underlying records. Switch between proposals and accepted mappings. Record contextual/supporting/contradicting relationships explicitly; time proximity alone is never a proven attack sequence. Create a separate finding with an assessment while preserving the source.

The curated six-technique subset links to the official MITRE pages checked on 4 November 2026. It is not a complete ATT&CK matrix and does not measure detection coverage. Keyword rules are explainable proposals, not confirmed malicious activity or attribution.

## Imports and Team exchange

Normalized JSON arrays, `{records:[…]}` and CSV are supported. Examples are included. Import fields: `kind,title,description,source,source_event_id,asset,observed_at,severity,certainty,confidence,techniques`. Imported records require a title and ISO observation time with timezone. CSV technique IDs use semicolons. Maximum 500 records per import, 2 MB per request and 1000 stored records. Exact duplicates are skipped; changed source-event versions remain separate from earlier reviewed records.

When launched as a CAMT module with an existing team configuration, the optional bridge delegates to CAMT's existing TeamService and entitlement checks. Explicitly fetch dossiers/import observations or findings. Imported server records await local review. Publishing a selected reviewed finding requires confirmation and uses stable object IDs and server revisions; conflicts never force an overwrite. No server credentials are exposed to the browser. Check server state after ambiguous network failures before retrying publication.

## Scope and privacy

No direct NAG/Elastic/Kibana connectors, polling, webhooks, photo uploads, speech recognition, native APK update, full catalog, coverage scoring, automated enrichment, attribution or production personal-authentication system is included.

Default binding is loopback. LAN HTTP is explicitly enabled and unencrypted, for test data on a trusted network only. Keep the firewall enabled and restrict port access to a private network. The access code grants access to the entire PoC, including available team actions. No individual roles exist. Sessions expire after eight hours and restart invalidates them. Local SQLite storage is not additionally encrypted.

Module data lives in CAMT's separate `observation-intel-poc` user-data folder. Standalone data lives in `data/poc.sqlite`. Snapshots contain records, relationships, import results and the latest 200 audit events, excluding credentials. They are not restore packages; stop the PoC and copy the database for a full backup. Records are retained; a complete editing/deletion/recovery workflow is future work.

Server/domain tests and isolated Team protocol tests passed. Desktop browser operations, NL/EN UI and a 390×844 mobile viewport were checked. Testing on a physical phone and integration within your frozen CAMT module host remain user-side validation steps.

Support: cyberfirepulse@gmail.com
