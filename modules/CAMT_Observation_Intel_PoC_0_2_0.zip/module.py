from __future__ import annotations
import importlib.util,json,sys,threading,webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox

MODULE_ID='camt.observation_intel.poc'

def open_workspace(context,manager,profile):
 app=context.get('app');parent=context.get('parent') or getattr(app,'root',None)
 previous=getattr(app,'_observation_intel_poc',None)
 if previous and previous.winfo_exists():previous.deiconify();previous.lift();return {'window':previous}
 lang=context.get('language','en')
 if app is not None and hasattr(app,'language_var'):lang=app.language_var.get()
 lang='nl' if str(lang).lower().startswith('nl') else 'en'
 root=Path(__file__).parent;words=json.loads((root/'web/locales'/f'{lang}.json').read_text(encoding='utf-8'))
 spec=importlib.util.spec_from_file_location('camt_observation_intel_poc_server',root/'server.py');servermod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=servermod;spec.loader.exec_module(servermod)
 data_dir=Path(manager.home)/'observation-intel-poc'
 factory=getattr(app,'_new_tool_window',None);win=factory() if callable(factory) else tk.Toplevel(parent)
 if app is not None:app._observation_intel_poc=win
 win.title(words['launcher_title']);scale=max(1,float(win.tk.call('tk','scaling'))/(96/72));win.geometry(f'{round(680*scale)}x{round(520*scale)}');win.configure(bg='#11283e')
 header=tk.Frame(win,bg='#11283e',padx=18,pady=14);header.pack(fill='x')
 tk.Label(header,text=words['launcher_title'],bg='#11283e',fg='#71e1d7',font=('Segoe UI',19,'bold')).pack(anchor='w')
 tk.Label(header,text=words['launcher_intro'],bg='#11283e',fg='#d0e1f0',font=('Segoe UI',10),wraplength=round(620*scale),justify='left').pack(anchor='w',pady=8)
 body=ttk.Frame(win,padding=18);body.pack(fill='both',expand=True)
 lan=tk.BooleanVar(value=False);check=ttk.Checkbutton(body,text=words['lan_option'],variable=lan);check.pack(anchor='w',pady=8)
 url=tk.StringVar(value='—');code=tk.StringVar(value='—');status=tk.StringVar(value=words['launcher_stopped']);holder={'server':None,'thread':None}
 for key,var in [('local_url',url),('access_code',code)]:
  ttk.Label(body,text=words[key]).pack(anchor='w',pady=(10,3));ttk.Entry(body,textvariable=var,state='readonly',font=('Consolas',12)).pack(fill='x')
 ttk.Label(body,text=words['lan_hint'],wraplength=round(620*scale),justify='left').pack(fill='x',pady=12)
 ttk.Label(body,text=words['data_folder']+': '+str(data_dir),wraplength=round(620*scale)).pack(fill='x')
 bar=ttk.Frame(body);bar.pack(fill='x',pady=16)
 def start():
  if holder['server']:return
  try:
   service=None
   if app is not None and callable(getattr(app,'_team_service',None)):
    candidate=app._team_service()
    if candidate.config.mode=='team' and candidate.config.server_url and candidate.config.api_token:service=candidate
   server=servermod.Server('0.0.0.0' if lan.get() else '127.0.0.1',8787,data_dir,service)
   holder['server']=server;thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.1},daemon=True,name='CAMT-Intel-PoC');thread.start();holder['thread']=thread
   url.set(server.url);code.set(server.code);status.set(words['ready']);check.configure(state='disabled');webbrowser.open(server.url)
  except Exception as e:messagebox.showerror(words['operation_failed'],str(e),parent=win)
 def stop():
  server=holder['server']
  if server:server.shutdown();server.server_close();holder['thread'].join(timeout=2);holder['server']=None
  url.set('—');code.set('—');status.set(words['launcher_stopped']);check.configure(state='normal')
 def close():stop();win.destroy()
 ttk.Button(bar,text=words['start_server'],command=start).pack(side='left',padx=(0,8))
 ttk.Button(bar,text=words['open_browser'],command=lambda:webbrowser.open(holder['server'].url) if holder['server'] else None).pack(side='left',padx=(0,8))
 ttk.Button(bar,text=words['stop_server'],command=stop).pack(side='left')
 ttk.Label(body,textvariable=status).pack(fill='x')
 win.protocol('WM_DELETE_WINDOW',close)
 return {'window':win}

def run(context,manager,profile):return open_workspace(context,manager,profile)
