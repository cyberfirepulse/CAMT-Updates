"""CAMT Observation Intel PoC. Isolated SQLite data; standard library only.

No threat attribution, detection coverage calculation or automatic validation.
"""
from __future__ import annotations
import copy,csv,hashlib,hmac,io,json,os,re,secrets,sqlite3,threading,time,uuid
from datetime import datetime,timezone,timedelta
from pathlib import Path

ROOT=Path(__file__).resolve().parent
CATALOG=json.loads((ROOT/'catalog.json').read_text(encoding='utf-8'))
TECH={t['id']:t for t in CATALOG['techniques']}
KINDS={'observation','alert','finding','question'}
SEVERITIES={'info','low','medium','high','critical'}
CERTAINTIES={'observed','reported','inferred'}
CONFIDENCES={'low','medium','high','unknown'}
MAX_BODY=2*1024*1024

class Problem(Exception):
 def __init__(self,code,message):self.code=code;self.message=message;super().__init__(message)

def now():return datetime.now(timezone.utc).isoformat(timespec='seconds')
def dump(v):return json.dumps(v,ensure_ascii=False,separators=(',',':'),sort_keys=True)
def uid():return str(uuid.uuid4())
def clean(value,maximum=20000):
 if not isinstance(value,str) or len(value)>maximum:raise Problem(400,'invalid_text')
 return value.strip()
def timestamp(value):
 try:
  dt=datetime.fromisoformat(value.replace('Z','+00:00'))
  if dt.tzinfo is None:raise ValueError()
  return dt.astimezone(timezone.utc).isoformat(timespec='seconds')
 except (ValueError,AttributeError):raise Problem(400,'invalid_time')

def proposals(record):
 text=(record['title']+' '+record['description']).lower()
 result=[]
 for tid,t in TECH.items():
  hits=[term for term in t['terms'] if re.search(r'(?<!\w)'+re.escape(term)+r'(?!\w)',text)]
  if hits:result.append({'technique_id':tid,'origin':'keyword_rule','reason':', '.join(hits),'state':'proposed','note':'','analyst':''})
 for tid in record.get('techniques',[]):
  if tid not in TECH:raise Problem(400,'unsupported_technique')
  if not any(x['technique_id']==tid for x in result):result.append({'technique_id':tid,'origin':'source_mapping','reason':tid,'state':'proposed','note':'','analyst':''})
 return result

def normalize(v,origin='manual'):
 if not isinstance(v,dict):raise Problem(400,'invalid_record')
 title=clean(v.get('title',''),300)
 if not title:raise Problem(400,'title_required')
 kind=v.get('kind','observation');severity=v.get('severity','info');certainty=v.get('certainty','reported');confidence=v.get('confidence','unknown')
 if kind not in KINDS or severity not in SEVERITIES or certainty not in CERTAINTIES or confidence not in CONFIDENCES:raise Problem(400,'invalid_enum')
 techniques=v.get('techniques',[])
 if isinstance(techniques,str):techniques=[x.strip() for x in techniques.split(';') if x.strip()]
 if not isinstance(techniques,list) or any(not isinstance(x,str) for x in techniques):raise Problem(400,'invalid_techniques')
 return {'id':uid(),'revision':1,'kind':kind,'title':title,'description':clean(v.get('description',v.get('observation',''))),
  'source':clean(v.get('source',''),600),'source_event_id':clean(v.get('source_event_id',''),300),
  'asset':clean(v.get('asset',''),300),'observed_at':timestamp(v.get('observed_at',now())),
  'severity':severity,'certainty':certainty,'confidence':confidence,'origin':origin,'demo':origin=='demo',
  'analyst':clean(v.get('analyst',''),120),'assessment':clean(v.get('assessment','')),'follow_up':clean(v.get('follow_up','')),
  'status':'pending','created_at':now(),'techniques':techniques}

class Store:
 def __init__(self,path):
  self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
  with self.db() as c:c.executescript('''
   CREATE TABLE IF NOT EXISTS history(item_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(item_id,revision));
   CREATE TABLE IF NOT EXISTS drafts(id TEXT PRIMARY KEY,revision INTEGER NOT NULL,payload TEXT NOT NULL,updated_at TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,revision INTEGER NOT NULL,payload TEXT NOT NULL,fingerprint TEXT UNIQUE);
   CREATE TABLE IF NOT EXISTS links(id TEXT PRIMARY KEY,left_id TEXT NOT NULL,right_id TEXT NOT NULL,relation TEXT NOT NULL,note TEXT NOT NULL,analyst TEXT NOT NULL,created_at TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS audit(seq INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,action TEXT NOT NULL,item_id TEXT NOT NULL,analyst TEXT NOT NULL,detail TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,at TEXT NOT NULL,source TEXT NOT NULL,payload TEXT NOT NULL);
   CREATE TABLE IF NOT EXISTS published(item_id TEXT NOT NULL,origin TEXT NOT NULL,case_id TEXT NOT NULL,object_id TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(item_id,origin,case_id));
  ''')
 def db(self):
  c=sqlite3.connect(self.path,timeout=10);c.row_factory=sqlite3.Row
  return ClosingConnection(c)
 def audit(self,c,action,item='',analyst='',detail=''):
  c.execute('INSERT INTO audit(at,action,item_id,analyst,detail) VALUES(?,?,?,?,?)',(now(),action,item,analyst,detail))
 def item(self,c,i):
  r=c.execute('SELECT payload FROM items WHERE id=?',(i,)).fetchone()
  if not r:raise Problem(404,'not_found')
  return json.loads(r[0])
 def get(self,i):
  with self.db() as c:return self.item(c,i)
 def state(self):
  with self.db() as c:
   items=[json.loads(r[0]) for r in c.execute('SELECT payload FROM items ORDER BY rowid DESC')]
   links=[dict(r) for r in c.execute('SELECT * FROM links ORDER BY created_at DESC')]
   audit=[dict(r) for r in c.execute('SELECT * FROM audit ORDER BY seq DESC LIMIT 200')]
   drafts=[{**json.loads(r['payload']),'draft_id':r['id'],'draft_revision':r['revision'],'updated_at':r['updated_at']} for r in c.execute('SELECT * FROM drafts ORDER BY updated_at DESC')]
   runs=[{**dict(r),'payload':json.loads(r['payload'])} for r in c.execute('SELECT * FROM runs ORDER BY at DESC LIMIT 30')]
  candidates=[]
  existing={tuple(sorted((l['left_id'],l['right_id']))) for l in links}
  for i,a in enumerate(items):
   if not a['asset']:continue
   for b in items[i+1:]:
    if a['asset'].casefold()!=b['asset'].casefold() or tuple(sorted((a['id'],b['id']))) in existing:continue
    if abs((datetime.fromisoformat(a['observed_at'])-datetime.fromisoformat(b['observed_at'])).total_seconds())<=7200:
     candidates.append({'left_id':a['id'],'right_id':b['id'],'reason':'same_asset_time'})
    if len(candidates)>=100:break
   if len(candidates)>=100:break
  return {'items':items,'links':links,'candidates':candidates,'audit':audit,'runs':runs,'catalog':CATALOG,'drafts':drafts}
 def add(self,data,origin='manual'):
  r=normalize(data,origin)
  if origin=='manual' and not r['analyst']:raise Problem(400,'analyst_required')
  r['mappings']=proposals(r)
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE')
   if c.execute('SELECT COUNT(*) FROM items').fetchone()[0]>=1000:raise Problem(400,'storage_limit')
   if data.get('draft_id'):
    draft=c.execute('SELECT revision FROM drafts WHERE id=?',(data['draft_id'],)).fetchone()
    if not draft or draft[0]!=data.get('draft_revision'):raise Problem(409,'revision_conflict')
    c.execute('DELETE FROM drafts WHERE id=?',(data['draft_id'],))
   c.execute('INSERT INTO items VALUES(?,?,?,NULL)',(r['id'],1,dump(r)))
   self.audit(c,'record.created',r['id'],r['analyst'],r['kind'])
  return r
 def snapshot(self,c,r):
  c.execute('INSERT OR IGNORE INTO history VALUES(?,?,?)',(r['id'],r['revision'],dump(r)))
 def history(self,item_id):
  with self.db() as c:
   current=self.item(c,item_id)
   return [current]+[json.loads(row[0]) for row in c.execute('SELECT payload FROM history WHERE item_id=? ORDER BY revision DESC',(item_id,))]
 def edit(self,data):
  analyst=clean(data.get('analyst',''),120);reason=clean(data.get('reason',''),4000)
  if not analyst or not reason:raise Problem(400,'reason_required')
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');r=self.item(c,data.get('id',''))
   if data.get('base_revision')!=r['revision']:raise Problem(409,'revision_conflict')
   values=data.get('values')
   if not isinstance(values,dict):raise Problem(400,'invalid_record')
   fields=('title','description','source','asset','observed_at','severity','certainty','confidence','assessment','follow_up')
   normalized=normalize({**r,**{k:values[k] for k in fields if k in values}},r['origin'])
   research=values.get('research_status',r.get('research_status','open'))
   if research not in {'open','investigating','waiting','resolved'}:raise Problem(400,'invalid_enum')
   self.snapshot(c,r)
   content_changed=any(normalized[k]!=r[k] for k in fields if k!='follow_up')
   r.update({k:normalized[k] for k in fields})
   if content_changed:
    # Previous decisions remain in history; changed evidence requires fresh review.
    r['mappings']=proposals(r);r['status']='pending'
   r.update(research_status=research,revision=r['revision']+1,updated_at=now(),updated_by=analyst,change_reason=reason)
   c.execute('UPDATE items SET revision=?,payload=? WHERE id=?',(r['revision'],dump(r),r['id']))
   self.audit(c,'record.edited',r['id'],analyst,reason)
  return r
 def save_draft(self,data):
  values=data.get('values')
  if not isinstance(values,dict):raise Problem(400,'invalid_record')
  fields=('kind','title','description','source','asset','observed_at','severity','certainty','confidence','assessment','follow_up')
  values={k:clean(v,20000) for k,v in values.items() if k in fields}
  key=clean(data.get('draft_id',''),100) or uid()
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');old=c.execute('SELECT revision FROM drafts WHERE id=?',(key,)).fetchone()
   if old and data.get('draft_revision')!=old[0]:raise Problem(409,'revision_conflict')
   if not old and data.get('draft_revision'):raise Problem(409,'revision_conflict')
   if not old and c.execute('SELECT COUNT(*) FROM drafts').fetchone()[0]>=100:raise Problem(400,'storage_limit')
   rev=old[0]+1 if old else 1
   c.execute('INSERT OR REPLACE INTO drafts VALUES(?,?,?,?)',(key,rev,dump(values),now()))
  return {**values,'draft_id':key,'draft_revision':rev}
 def delete_draft(self,data):
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE')
   row=c.execute('SELECT revision FROM drafts WHERE id=?',(data.get('draft_id'),)).fetchone()
   if not row:raise Problem(404,'not_found')
   if data.get('draft_revision')!=row[0]:raise Problem(409,'revision_conflict')
   c.execute('DELETE FROM drafts WHERE id=?',(data['draft_id'],))
  return {'ok':True}
 def review(self,data):
  item=clean(data.get('id',''),100);analyst=clean(data.get('analyst',''),120);note=clean(data.get('note',''),4000)
  if not analyst or not note:raise Problem(400,'reason_required')
  state=data.get('state');tid=data.get('technique_id')
  if tid not in TECH or state not in {'accepted','rejected'}:raise Problem(400,'invalid_decision')
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');r=self.item(c,item)
   if data.get('base_revision')!=r['revision']:raise Problem(409,'revision_conflict')
   self.snapshot(c,r)
   mapping=next((m for m in r['mappings'] if m['technique_id']==tid),None)
   if mapping is None:
    mapping={'technique_id':tid,'origin':'analyst_mapping','reason':'manual','state':'proposed'};r['mappings'].append(mapping)
   mapping.update(state=state,note=note,analyst=analyst,decided_at=now());r['revision']+=1
   r['status']='reviewed' if all(m['state']!='proposed' for m in r['mappings']) else 'pending'
   c.execute('UPDATE items SET revision=?,payload=? WHERE id=?',(r['revision'],dump(r),item))
   self.audit(c,'mapping.'+state,item,analyst,tid+': '+note)
  return r
 def decision(self,data):
  analyst=clean(data.get('analyst',''),120);note=clean(data.get('note',''),4000);state=data.get('state')
  if not analyst or not note:raise Problem(400,'reason_required')
  if state not in {'reviewed','dismissed'}:raise Problem(400,'invalid_decision')
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');r=self.item(c,data.get('id',''))
   if data.get('base_revision')!=r['revision']:raise Problem(409,'revision_conflict')
   self.snapshot(c,r)
   r.update(status=state,assessment=note,reviewer=analyst,revision=r['revision']+1)
   c.execute('UPDATE items SET revision=?,payload=? WHERE id=?',(r['revision'],dump(r),r['id']))
   self.audit(c,'record.'+state,r['id'],analyst,note)
  return r
 def promote(self,data):
  analyst=clean(data.get('analyst',''),120);assessment=clean(data.get('assessment',''),4000)
  if not analyst or not assessment:raise Problem(400,'reason_required')
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');r=self.item(c,data.get('id',''))
   if r['revision']!=data.get('base_revision'):raise Problem(409,'revision_conflict')
   if c.execute('SELECT COUNT(*) FROM items').fetchone()[0]>=1000:raise Problem(400,'storage_limit')
   if r['kind']=='finding':raise Problem(400,'already_finding')
   f=copy.deepcopy(r);f.update(id=uid(),kind='finding',derived_from=r['id'],assessment=assessment,analyst=analyst,status='reviewed',revision=1,created_at=now())
   c.execute('INSERT INTO items VALUES(?,?,?,NULL)',(f['id'],1,dump(f)))
   c.execute('INSERT INTO links VALUES(?,?,?,?,?,?,?)',(uid(),r['id'],f['id'],'context','derived finding',analyst,now()))
   self.audit(c,'finding.created',f['id'],analyst,'source='+r['id']+'; '+assessment)
  return f
 def link(self,data):
  left=clean(data.get('left_id',''),100);right=clean(data.get('right_id',''),100)
  analyst=clean(data.get('analyst',''),120);note=clean(data.get('note',''),4000);relation=data.get('relation')
  if left==right or relation not in {'supports','contradicts','context'}:raise Problem(400,'invalid_link')
  if not analyst or not note:raise Problem(400,'reason_required')
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');self.item(c,left);self.item(c,right)
   duplicate=c.execute('SELECT id FROM links WHERE (left_id=? AND right_id=?) OR (left_id=? AND right_id=?)',(left,right,right,left)).fetchone()
   if duplicate:raise Problem(409,'duplicate_link')
   key=uid();c.execute('INSERT INTO links VALUES(?,?,?,?,?,?,?)',(key,left,right,relation,note,analyst,now()))
   self.audit(c,'link.created',left,analyst,right+': '+relation+'; '+note)
  return {'id':key}
 def import_records(self,records,origin='file',source_name='JSON / CSV'):
  if not isinstance(records,list) or len(records)>500:raise Problem(400,'import_limit')
  counts={'new':0,'versions':0,'duplicates':0,'rejected':0,'errors':[]}
  # Validate before starting the transaction; malformed records are accounted for.
  normalized=[]
  for i,v in enumerate(records):
   try:
    if not isinstance(v,dict) or not v.get('observed_at'):raise Problem(400,'missing_import_time')
    r=normalize(v,origin);r['mappings']=proposals(r);normalized.append((i,r))
   except Problem as e:counts['rejected']+=1;counts['errors'].append({'row':i+1,'error':e.message})
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE')
   for i,r in normalized:
    basis={k:r[k] for k in ('kind','title','description','source','source_event_id','asset','observed_at','severity','certainty','confidence','techniques','assessment','follow_up')}
    fingerprint=hashlib.sha256(dump(basis).encode()).hexdigest()
    if c.execute('SELECT id FROM items WHERE fingerprint=?',(fingerprint,)).fetchone():counts['duplicates']+=1;continue
    if c.execute('SELECT COUNT(*) FROM items').fetchone()[0]>=1000:
     counts['rejected']+=1;counts['errors'].append({'row':i+1,'error':'storage_limit'});continue
    previous=None
    if r['source_event_id']:
     for row in c.execute('SELECT payload FROM items ORDER BY rowid DESC'):
      p=json.loads(row[0])
      if p['source']==r['source'] and p['source_event_id']==r['source_event_id']:previous=p;break
    if previous:r['supersedes']=previous['id'];counts['versions']+=1
    else:counts['new']+=1
    c.execute('INSERT INTO items VALUES(?,?,?,?)',(r['id'],1,dump(r),fingerprint));self.audit(c,'record.imported',r['id'],r['analyst'],origin)
   c.execute('INSERT INTO runs VALUES(?,?,?,?)',(uid(),now(),source_name,dump(counts)))
  return counts
 def seed(self):return self.import_records(demo(),'demo','Demo fixture')

class ClosingConnection:
 def __init__(self,c):self.c=c
 def __enter__(self):return self.c
 def __exit__(self,kind,value,tb):
  try:
   if kind:self.c.rollback()
   else:self.c.commit()
  finally:self.c.close()

def demo():
 base=datetime(2026,11,4,9,tzinfo=timezone.utc)
 rows=[
  ('observation','Bezoek op locatie: onverwachte PowerShell','De medewerker meldt een PowerShell-venster op een werkstation. Nog geen proceslog beschikbaar.','WS-DEMO-01','medium','reported','medium',[]),
  ('alert','DEMO — PowerShell process event','Synthetisch proceslog: powershell op WS-DEMO-01. Er is nog geen inhoudelijke beoordeling.','WS-DEMO-01','high','reported','unknown',['T1059']),
  ('observation','Verdachte phishing-mail gemeld','Gebruiker toont een phishing-mail met een link. De mail is nog niet technisch onderzocht.','WS-DEMO-01','medium','observed','high',[]),
  ('alert','DEMO — Remote desktop sessie','Synthetisch RDP-event naar de testserver. Toegestaan beheer is nog niet uitgesloten.','SRV-DEMO-01','high','reported','unknown',[]),
  ('observation','Onverwachte beheeractiviteit','In het testdossier wordt melding gemaakt van stolen credentials. Dit is nog een onbevestigde verklaring.','SRV-DEMO-01','high','reported','low',[]),
  ('alert','DEMO — Files encrypted melding','Synthetische files encrypted melding. Hersteltest of kwaadaardige actie is nog niet vastgesteld.','SRV-DEMO-01','critical','reported','unknown',[]),
  ('alert','DEMO — Door bron aangeleverde C2-mapping','Synthetische bron kent T1041 toe. De bijbehorende netwerkgegevens moeten nog worden getoetst.','SRV-DEMO-01','high','reported','low',['T1041']),
  ('observation','Onbekend netwerkapparaat','Een niet-gelabeld apparaat aangetroffen. Geen aanwijzing voor een aanvalstechniek.','SW-DEMO-02','low','observed','high',[]),
 ]
 return [dict(kind=k,title=t,description=d,asset=a,severity=s,certainty=c,confidence=f,techniques=tech,source='FICTIEVE DEMO',source_event_id='fixture-'+str(i),observed_at=(base+timedelta(minutes=5*i)).isoformat(),analyst='Demo-analist') for i,(k,t,d,a,s,c,f,tech) in enumerate(rows)]

class TeamBridge:
 """Optional module-only bridge; credentials never leave the existing TeamService."""
 def __init__(self,service,store):
  self.service=copy.copy(service);self.service.config=copy.copy(service.config);self.original=service;self.store=store;self.lock=threading.Lock()
 def call(self,method,path,data=None):
  if (self.original.config.server_url,self.original.config.api_token)!=(self.service.config.server_url,self.service.config.api_token):raise Problem(409,'team_config_changed')
  return self.service.api_request(method,path,data)
 def cases(self):return self.call('GET','/api/v1/cases').get('cases',[])
 def pull(self,cid):
  from urllib.parse import quote
  cases=self.cases()
  if not any(x['case_id']==cid for x in cases):raise Problem(404,'case_not_found')
  rows=self.call('GET','/api/v1/cases/'+quote(cid,safe='')+'/objects').get('objects',[]);records=[]
  for row in rows:
   if row.get('object_type') not in {'finding','observation'}:continue
   p=row['payload'];p=json.loads(p) if isinstance(p,str) else p
   sev=str(p.get('severity','info')).lower();sev=sev if sev in SEVERITIES else 'info'
   at=p.get('observed_at') or row.get('updated_at') or now()
   records.append({'kind':row['object_type'],'title':p.get('title','Untitled'),'description':p.get('observation',p.get('body','')),
    'source':'CAMT Team '+cid,'source_event_id':self.service.config.server_url+'|'+cid+'|'+row['object_id'],
    'asset':p.get('asset_id',p.get('asset','')),'observed_at':at,'severity':sev,'certainty':'reported','confidence':'unknown',
    'assessment':p.get('assessment',''),'follow_up':p.get('action',''),'analyst':row.get('author_id','')})
  return self.store.import_records(records,'team','CAMT Team '+cid)
 def publish(self,item_id,cid,analyst,base_revision):
  from urllib.parse import quote
  if not clean(analyst,120):raise Problem(400,'analyst_required')
  if not any(x['case_id']==cid for x in self.cases()):raise Problem(404,'case_not_found')
  item=self.store.get(item_id)
  if item['revision']!=base_revision:raise Problem(409,'revision_conflict')
  if item['kind']!='finding' or item['status']!='reviewed':raise Problem(400,'reviewed_finding_required')
  if not self.service.config.user_id:raise Problem(400,'team_user_required')
  with self.lock:
   origin=self.service.config.server_url
   with self.store.db() as c:p=c.execute('SELECT * FROM published WHERE item_id=? AND origin=? AND case_id=?',(item_id,origin,cid)).fetchone()
   oid=p['object_id'] if p else 'poc-'+item_id;revision=p['revision'] if p else 0
   body={'object_type':'finding','object_id':oid,'base_revision':revision,'user_id':self.service.config.user_id,
    'change_summary':'Observation Intel PoC: explicit publish','payload':{'title':item['title'],'body':item['description'],
    'observation':item['description'],'source':item['source'],'action':item['follow_up'],'severity':item['severity'],'status':'review',
    'assessment':item['assessment'],'poc_source_id':item['id'],'attack_mappings':item['mappings']}}
   result=self.call('POST','/api/v1/cases/'+quote(cid,safe='')+'/objects',body)
   with self.store.db() as c:
    c.execute('INSERT OR REPLACE INTO published VALUES(?,?,?,?,?)',(item_id,origin,cid,oid,int(result['revision'])))
    self.store.audit(c,'team.published',item_id,analyst,cid+' revision '+str(result['revision']))
   return result
