#!/usr/bin/env bash
set -Eeuo pipefail

# User requirement: never create or use a venv without explicit user approval.

CAMT_HOME="/opt/camt"
CAMT_PACKAGES="$CAMT_HOME/python-packages"
PYTHON_RELEASE="3.12.15"
PYTHON_PREFIX="/opt/camt-python/$PYTHON_RELEASE"
CAMT_LAUNCHER="/usr/local/bin/camt"
MIN_PY="3.12"
unset PYTHONHOME PYTHONPATH
export PYTHONNOUSERSITE=1

die(){ echo "ERROR: $*" >&2; exit 1; }
trap 'echo "ERROR: CAMT installer stopped at line $LINENO." >&2' ERR

[ "$(uname -s)" = "Linux" ] || die "Linux is required."
[ "$(id -u)" -eq 0 ] || die "Run: sudo bash packaging/linux/install.sh"

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
[ -f "$SOURCE_DIR/pyproject.toml" ] || die "Incomplete CAMT source tree."
[ -d "$SOURCE_DIR/src/projectmanager" ] || die "Missing src/projectmanager."
[ -f "$SOURCE_DIR/packaging/linux/camt" ] || die "Missing packaging/linux/camt."

PM=""
for x in apt-get dnf yum pacman zypper; do command -v "$x" >/dev/null 2>&1 && { PM="$x"; break; }; done
[ -n "$PM" ] || die "Supported package manager not found (apt/dnf/yum/pacman/zypper)."

echo "=== CAMT Beta 10 complete Linux installation ==="
echo "[1/8] Native Linux dependencies"

case "$PM" in
 apt-get)
   apt-get update
   DEBIAN_FRONTEND=noninteractive apt-get install -y \
     ca-certificates curl git rsync build-essential pkg-config \
     python3 python3-pip python3-dev python3-tk \
     libssl-dev libffi-dev libpcap-dev zlib1g-dev libbz2-dev liblzma-dev libsqlite3-dev libreadline-dev tk-dev xz-utils \
     libjpeg-dev libpng-dev libfreetype6-dev \
     nmap iproute2 net-tools traceroute dnsutils openssh-client \
     rustc cargo
   ;;
 dnf|yum)
   "$PM" install -y \
     ca-certificates curl git rsync gcc gcc-c++ make pkgconf-pkg-config \
     python3 python3-pip python3-devel python3-tkinter \
     openssl-devel libffi-devel libpcap-devel zlib-devel bzip2-devel xz-devel sqlite-devel readline-devel tk-devel xz \
     libjpeg-turbo-devel libpng-devel freetype-devel \
     nmap iproute net-tools traceroute bind-utils openssh-clients rust cargo
   ;;
 pacman)
   pacman -Syu --needed --noconfirm \
     ca-certificates curl git rsync base-devel pkgconf python python-pip tk \
     openssl libffi libpcap zlib bzip2 xz sqlite readline libjpeg-turbo libpng freetype2 \
     nmap iproute2 net-tools traceroute bind openssh rust
   ;;
 zypper)
   zypper --non-interactive refresh
   zypper --non-interactive install \
     ca-certificates curl git rsync gcc gcc-c++ make pkg-config \
     python3 python3-pip python3-devel python3-tk \
     libopenssl-devel libffi-devel libpcap-devel zlib-devel libbz2-devel xz-devel sqlite3-devel readline-devel tk-devel xz \
     libjpeg8-devel libpng16-devel freetype2-devel \
     nmap iproute2 net-tools traceroute bind-utils openssh rust cargo
   ;;
esac

echo "[2/8] Selecting standalone Python 3.12 (no virtual environment)"
usable_python(){
  [ -x "$1" ] && "$1" -I -c 'import sys, tkinter, _tkinter, ssl, sqlite3, bz2, lzma; import pip; raise SystemExit(0 if sys.version_info[:2] == (3,12) and sys.prefix == sys.base_prefix else 1)' >/dev/null 2>&1
}
find_python(){
  local p resolved
  for p in "$PYTHON_PREFIX/bin/python3.12" /usr/bin/python3.12 /usr/local/bin/python3.12; do
    if usable_python "$p"; then printf '%s\n' "$p"; return 0; fi
  done
  for p in python3.12 python3; do
    resolved="$(command -v "$p" || true)"
    if [ -n "$resolved" ] && usable_python "$resolved"; then printf '%s\n' "$resolved"; return 0; fi
  done
  return 1
}
CAMT_PYTHON="$(find_python || true)"
if [ -z "$CAMT_PYTHON" ]; then
  # Install a regular CPython alongside the distribution Python. Never change
  # /usr/bin/python3 or create/activate a virtual environment.
  echo "Installing Python $PYTHON_RELEASE alongside the system Python; this can take several minutes."
  PY_BUILD="$(mktemp -d)"
  trap 'rm -rf -- "$PY_BUILD"' EXIT
  curl --fail --location --retry 3 --proto '=https' --tlsv1.2 \
    "https://www.python.org/ftp/python/$PYTHON_RELEASE/Python-$PYTHON_RELEASE.tar.xz" \
    -o "$PY_BUILD/python.tar.xz"
  printf '%s  %s\n' 'c2c4321961fab0fb999d66e0cecf521c2ab3994c7992873ea99e306c1094fd5a' "$PY_BUILD/python.tar.xz" | sha256sum -c -
  tar -xJf "$PY_BUILD/python.tar.xz" -C "$PY_BUILD"
  (
    cd "$PY_BUILD/Python-$PYTHON_RELEASE"
    ./configure --prefix="$PYTHON_PREFIX" --with-ensurepip=install
    make -j "${CAMT_BUILD_JOBS:-2}"
    make altinstall
  )
  rm -rf -- "$PY_BUILD"
  trap - EXIT
  CAMT_PYTHON="$PYTHON_PREFIX/bin/python3.12"
fi
usable_python "$CAMT_PYTHON" || die "Standalone Python 3.12 with Tk, pip and SSL is required; no virtual environment will be created."
echo "Using: $CAMT_PYTHON ($("$CAMT_PYTHON" --version 2>&1))"

# Keep the previous program tree before replacing application files.
# User data must additionally be backed up from CAMT's configured data folder.
[ "$SOURCE_DIR" != "$CAMT_HOME" ] || die "Extract the update outside /opt/camt before installing."
if [ -d "$CAMT_HOME" ]; then
  install -d -m 0700 /opt/camt-backups
  CAMT_BACKUP="$(mktemp -d /opt/camt-backups/before-beta10-XXXXXXXX)"
  echo "Backing up current CAMT installation to $CAMT_BACKUP/camt"
  cp -a -- "$CAMT_HOME" "$CAMT_BACKUP/camt" || die "Installation backup failed; stopping."
fi

echo "[3/8] Installing CAMT source"
[ "$SOURCE_DIR" != "$CAMT_HOME" ] || die "Run from a source checkout outside $CAMT_HOME."
mkdir -p "$CAMT_HOME"
rsync -a --delete \
  --exclude '.git' --exclude '.venv' --exclude 'python-packages' --exclude '.python-path' --exclude 'build' --exclude 'dist' \
  "$SOURCE_DIR/" "$CAMT_HOME/"

echo "[4/8] Preparing CAMT packages (no virtual environment)"
VPY="$CAMT_PYTHON"
PACKAGE_STAGE="$(mktemp -d "$CAMT_HOME/.python-packages.XXXXXX")"
trap 'rm -rf -- "$PACKAGE_STAGE"' EXIT

echo "[5/8] Installing audited CAMT Python runtime"
# All runtime packages and the project are resolved together into an ordinary
# application package directory; no system Python packages are overwritten.
"$VPY" -I -m pip --isolated install --upgrade --ignore-installed --prefer-binary \
  --target "$PACKAGE_STAGE" \
  Pillow python-docx pypdf PyPDF2 "psycopg[binary]" \
  ropper capstone filebytes keystone-engine scapy requests cryptography "$CAMT_HOME"
export PYTHONPATH="$CAMT_HOME/src:$PACKAGE_STAGE"
"$VPY" -s -m pip check || die "CAMT Python dependency consistency check failed."

echo "[6/8] Full runtime verification"
"$VPY" - <<'PY'
import importlib, sys
required = [
 "tkinter","tkinter.ttk","tkinter.filedialog","tkinter.messagebox",
 "tkinter.simpledialog","tkinter.scrolledtext","tkinter.font","tkinter.colorchooser",
 "PIL","docx","pypdf","PyPDF2","psycopg","ropper","capstone","filebytes",
 "keystone","scapy","scapy.all","requests","cryptography",
 "cryptography.hazmat.primitives","projectmanager"
]
failed=[]
for name in required:
    try: importlib.import_module(name)
    except Exception as e: failed.append((name,repr(e)))
if failed:
    for n,e in failed: print(f"FAILED {n}: {e}", file=sys.stderr)
    raise SystemExit("CAMT runtime verification FAILED")
print("CAMT runtime imports: OK")
PY

# Audit absolute imports in CAMT source. This catches a newly introduced external
# dependency before the installer can claim success.
"$VPY" - "$CAMT_HOME" <<'PY'
import ast, pathlib, sys, importlib.util
root=pathlib.Path(sys.argv[1])
scan=[root/'src', root/'plugins']
missing={}
for base in scan:
    if not base.exists(): continue
    for path in base.rglob('*.py'):
        try: tree=ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
        except SyntaxError as e:
            raise SystemExit(f"Syntax error in {path}: {e}")
        for node in ast.walk(tree):
            names=[]
            if isinstance(node,ast.Import): names=[a.name.split('.')[0] for a in node.names]
            elif isinstance(node,ast.ImportFrom) and node.level==0 and node.module:
                names=[node.module.split('.')[0]]
            for name in names:
                if importlib.util.find_spec(name) is None:
                    missing.setdefault(name,set()).add(str(path.relative_to(root)))
# Local/sibling imports inside package/module files are resolved in their package context and
# can appear as top-level names in static AST; only report names used from multiple package files
# if the runtime cannot resolve them. The real module-load tests below remain authoritative.
external={k:v for k,v in missing.items() if k in {
    'PIL','docx','pypdf','PyPDF2','psycopg','ropper','capstone','filebytes','keystone',
    'scapy','requests','cryptography'
}}
if external:
    for name,paths in sorted(external.items()): print('MISSING',name,*sorted(paths),sep=' | ',file=sys.stderr)
    raise SystemExit('CAMT external dependency audit FAILED')
print('CAMT external dependency audit: OK')
PY

# Compile every Python source file: core + plugins + unpacked modules.
"$VPY" -B -m compileall -q "$CAMT_HOME/src" "$CAMT_HOME/plugins" 2>/dev/null || die "Python compile check failed."

# Scapy must load its real high-level runtime, not only the package root.
"$VPY" - <<'PY'
from scapy.all import IP, TCP, Ether, ARP, conf
from cryptography.hazmat.primitives import hashes
print("Scapy full load: OK")
print("Cryptography primitives: OK")
PY

# Publish the verified packages and exact native interpreter for the launcher.
rm -rf -- "$CAMT_PACKAGES"
mv -- "$PACKAGE_STAGE" "$CAMT_PACKAGES"
chmod -R a+rX "$CAMT_PACKAGES"
trap - EXIT
printf '%s\n' "$CAMT_PYTHON" > "$CAMT_HOME/.python-path"
chmod 0644 "$CAMT_HOME/.python-path"
export PYTHONPATH="$CAMT_HOME/src:$CAMT_PACKAGES"

echo "[7/8] Installing launcher and desktop integration"
install -d /usr/local/bin /usr/share/applications
install -m 0755 "$CAMT_HOME/packaging/linux/camt" "$CAMT_LAUNCHER"
if [ -f "$CAMT_HOME/packaging/linux/camt.desktop" ]; then
  install -m 0644 "$CAMT_HOME/packaging/linux/camt.desktop" /usr/share/applications/camt.desktop
fi

echo "[8/8] Launcher smoke test"
"$CAMT_LAUNCHER" --camt-launcher-check

echo
echo "========================================"
echo " CAMT installation completed successfully"
echo "========================================"
echo "Python  : $CAMT_PYTHON (no virtual environment)"
echo "Packages: $CAMT_PACKAGES"
echo "Start   : camt"
